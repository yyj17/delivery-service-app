import 'package:get/get.dart';
import 'package:getx_delivery_seller/binding/login_binding.dart';

import '../binding/app_info_binding.dart';
import '../binding/splash_screen_page_binding.dart';
import '../page/AppInfoPage.dart';
import '../page/auth/login_page.dart';
import '../page/auth/register_page.dart';
import '../page/home_page.dart';
import '../page/menu_page.dart';
import '../page/splash_screen_page.dart';
import 'app_routes.dart';

class AppPage {
  static final routes = [
    GetPage(
      name: AppRoutes.appInfoPage,
      page: () => const AppInfoPage(),
      binding: AppInfoBinding(),
    ),
    GetPage(
      name: AppRoutes.splashScreenPage,
      page: () => const SplashScreenPage(),
      binding: SplashScreenPageBinding(),
    ),
    GetPage(
      name: AppRoutes.loginPage,
      page: () => const LoginPage(),
      binding: LoginBinding(),
    ),
    GetPage(
      name: AppRoutes.registerPage,
      page: () => const RegisterPage(),
    ),
    GetPage(
      name: AppRoutes.homePage,
      page: () => const HomePage(),
    ),
  ];

  static final menuRoutes = [
    GetPage(
      name: AppRoutes.menuPage,
      page: () => const MenuPage(),
      children: routes,
    ),
  ];
}
