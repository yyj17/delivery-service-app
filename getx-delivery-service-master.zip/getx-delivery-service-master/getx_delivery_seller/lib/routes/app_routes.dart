class AppRoutes {
  static const String menuPage = "/menu";
  static const String appInfoPage = "/app_info_page";
  static const String splashScreenPage = "/splash_screen_page";
  static const String loginPage = "/login_page";
  static const String registerPage = "/register_page";
  static const String homePage = "/home_page";
}
