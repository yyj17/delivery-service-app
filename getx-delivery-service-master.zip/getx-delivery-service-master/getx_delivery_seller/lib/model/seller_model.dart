class SellerModel {
  final String status;
  final String email;
  final String name;
  final String avatarUrl;

  SellerModel({
    required this.status,
    required this.email,
    required this.name,
    required this.avatarUrl,
  });
}
