import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../res/label.dart';

mixin StateControllerMixin {
  String get noData => LocaleKeys.noData.tr;

  String get touch_screen_to_try_again => LocaleKeys.touchScreenToTryAgain.tr;

  Future showErrorDialog(String msg, {VoidCallback? onSubmit}) async {
    if (Get.overlayContext != null) {}
  }

  Future showSuccessDialog(String msg, {VoidCallback? onSubmit}) async {}

  showLoading({bool barrierDismissible = false}) {
    if (Get.overlayContext != null) {}
  }

  stopLoading() {
    if (Get.overlayContext != null) {}
  }

  Future showUnauthorizedDialog(String msg) async {
    if (Get.overlayContext != null) {}
  }
}
