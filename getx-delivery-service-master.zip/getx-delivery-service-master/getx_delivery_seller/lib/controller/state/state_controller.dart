import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_connect/http/src/status/http_status.dart';

import '../../server/response_entity.dart';
import '../../widgets/state/view_state_busy_widget.dart';
import '../../widgets/state/view_state_empty_widget.dart';
import '../../widgets/state/view_state_info_widget.dart';
import '../../widgets/state/view_state_widget.dart';
import 'state_controller_mixin.dart';

enum ViewState { idle, busy, empty, info, error }

/// controller to handle the page view
class StateController extends GetxController with StateControllerMixin {
  ViewState viewState = ViewState.idle;

  String? _message;

  bool get idle => viewState == ViewState.idle;

  bool get busy => viewState == ViewState.busy;

  bool get empty => viewState == ViewState.empty;

  bool get info => viewState == ViewState.info;

  bool get error => viewState == ViewState.error;

  void setBusy(bool value) {
    _message = null;
    viewState = value ? ViewState.busy : ViewState.idle;
    update();
  }

  void setEmpty() {
    _message = null;
    viewState = ViewState.empty;
    update();
  }

  void setInfo(String message) {
    _message = message;
    viewState = ViewState.info;
    update();
  }

  void setError(String message) {
    _message = message;
    viewState = ViewState.error;
    update();
  }

  /// init data on refresh
  initData() async {}

  /// this function will not call update, after call this function must update the controller
  checkEntity(ResponseEntity entity, {bool needStopLoading = true}) {
    if (entity.success) {
      if (needStopLoading) {
        viewState = ViewState.idle;
        stopLoading();
      }
      return true;
    } else {
      viewState = ViewState.error;
      _message = entity.message;
      stopLoading();

      _handleError(entity);
      return false;
    }
  }

  _handleError(ResponseEntity entity) {
    if (entity.statusCode == HttpStatus.unauthorized) {
      showUnauthorizedDialog(entity.message);
    } else if (entity.statusCode == HttpStatus.badRequest) {
      showErrorDialog(entity.message);
    } else {
      showErrorDialog(entity.message);
    }
  }

  Widget showViewByState({
    required Widget child,
    Widget? viewEmpty,
    Widget? viewBusy,
    bool isSliver = false,
    bool? wrapListView,
  }) {
    Widget content;

    switch (viewState) {
      case ViewState.idle:
        return child;
      case ViewState.busy:
        content = viewBusy ?? const ViewStateBusyWidget();
        break;
      case ViewState.empty:
        content = viewEmpty ??
            ViewStateEmptyWidget(
                message: noData,
                buttonText: touch_screen_to_try_again,
                wrapListView: wrapListView,
                onPressed: () {
                  initData();
                });
        break;
      case ViewState.error:
        content = ViewStateWidget(
          message: _message ?? '',
          buttonText: touch_screen_to_try_again,
          wrapListView: wrapListView,
          onPressed: () {
            initData();
          },
        );
        break;
      case ViewState.info:
        content = ViewStateInfoWidget(
          message: _message ?? '',
          wrapListView: wrapListView,
        );
        break;
    }

    if (isSliver) {
      return SliverFillRemaining(
        child: content,
      );
    } else {
      return content;
    }
  }
}
