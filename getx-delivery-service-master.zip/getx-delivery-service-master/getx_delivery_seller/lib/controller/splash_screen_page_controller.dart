import 'package:get/get.dart';
import 'package:getx_delivery_seller/service/auth_service.dart';

import 'state/state_controller.dart';

class SplashScreenPageController extends StateController {
  AuthService get _authService => Get.find<AuthService>();

  bool get isAuthenticated => _authService.isAuthenticated();
}
