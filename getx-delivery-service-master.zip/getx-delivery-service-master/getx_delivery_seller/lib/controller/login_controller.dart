import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../model/seller_model.dart';
import '../res/shared_preference_key.dart';
import '../routes/app_routes.dart';
import '../service/auth_service.dart';
import '../service/seller_service.dart';
import '../widgets/error_dialog.dart';
import '../widgets/loading_dialog.dart';
import 'state/state_controller.dart';

class LoginController extends StateController {
  AuthService get _authService => Get.find<AuthService>();

  SellerService get _sellerService => Get.find<SellerService>();

  SharedPreferences get _sharedPreferences => Get.find<SharedPreferences>();

  final GlobalKey<FormState> formKey = GlobalKey<FormState>();
  TextEditingController emailController = TextEditingController();
  TextEditingController passwordController = TextEditingController();

  //form validation for login
  formValidation() {
    if (emailController.text.isNotEmpty && passwordController.text.isNotEmpty) {
      //login
      _loginNow();
    } else {
      Get.dialog(
        ErrorDialog(
          message: "Please enter email/password.",
        ),
      );
    }
  }

  //login function
  _loginNow() async {
    Get.dialog(
      LoadingDialog(
        message: "Checking Credentials...",
      ),
    );

    try {
      User? currentUser = await _authService.signInWithEmailAndPassword(email: emailController.text.trim(), password: passwordController.text.trim());

      if (currentUser != null) {
        _readDataAndSetDataLocally(currentUser);
      }
    } catch (error) {
      Get.back();
      Get.dialog(
        ErrorDialog(
          message: error.toString(),
        ),
      );
    }
  }

  //read data from firestore and save it locally
  _readDataAndSetDataLocally(User currentUser) async {
    final uid = currentUser.uid;
    SellerModel? data = await _sellerService.getSellerData(uid);

    if (data != null) {
      if (data.status == "approved") {
        await _setDataToLocal(uid: uid, data: data);
        Get.back();
        Get.toNamed(AppRoutes.homePage);
      } else {
        _authService.signOut();
        Get.back();
        Fluttertoast.showToast(msg: "Your Account has been blocked");
      }
    } else {
      _authService.signOut();
      Get.back();
      Get.toNamed(AppRoutes.loginPage);
      Get.dialog(
        ErrorDialog(
          message: "No record exist.",
        ),
      );
    }
  }

  _setDataToLocal({required String uid, required SellerModel data}) async {
    await _sharedPreferences.setString(SharedPreferenceKey.uid, uid);
    await _sharedPreferences.setString(SharedPreferenceKey.email, data.email);
    await _sharedPreferences.setString(SharedPreferenceKey.name, data.name);
    await _sharedPreferences.setString(SharedPreferenceKey.photoUrl, data.avatarUrl);
  }
}
