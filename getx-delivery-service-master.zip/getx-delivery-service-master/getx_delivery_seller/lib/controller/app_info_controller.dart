import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../config/app_factory.dart';
import '../res/theme/app_theme.dart';
import '../service/general_service.dart';
import 'state/state_controller.dart';

class AppInfoController extends StateController {
  final appFactory = Get.find<AppFactory>();
  final generalService = GeneralService();
  final ip = "connecting".obs;
  final lbLanguage = "Chinese".obs;
  final localeList = [
    {"English": const Locale("en")},
    {"Chinese": const Locale("zh")},
  ];
  final themeModeList = [
    ThemeMode.light,
    ThemeMode.dark,
  ];

  late Locale currentLocale;
  late ThemeMode currentThemeMode = ThemeMode.light;
  late String currentThemeStyle;

  String get appName {
    return appFactory.appName;
  }

  String get appEnv {
    return appFactory.appEnv;
  }

  AppInfoController() {
    currentLocale = localeList.first.values.first;
    currentThemeStyle = AppTheme.instance.currentThemeStyle;
  }

  @override
  Future<void> onReady() async {
    super.onReady();
    await _updateLocalization(currentLocale);
    _updateAppInfo();
  }

  _updateAppInfo() async {
    setBusy(true);
    var entity = await generalService.getIpInfo();
    if (checkEntity(entity)) {
      ip.value = entity.data?.ip ?? "";
      setBusy(false);
    }
  }

  _updateLocalization(Locale locale) async {
    var entity = await generalService.getTranslation(locale.languageCode);
    if (entity.success) {
      List translationList = entity.data["translated_list"];
      Map<String, String> translationMap = translationList.asMap().map((key, value) => MapEntry(value["key"] ?? "", value["value"] ?? ""));

      Get.translations[locale.languageCode]?.addAll(translationMap);
    }
  }

  updateLanguge({Locale? locale}) async {
    locale = locale ?? localeList.first.values.first;
    currentLocale = locale;
    int localeIndex = localeList.indexWhere((element) => element.values.first == locale);
    lbLanguage.value = localeList[localeIndex].keys.first;

    await _updateLocalization(locale);
    Get.updateLocale(currentLocale);
  }

  updateThemeMode(ThemeMode themeMode) {
    updateTheme(currentThemeStyle, themeMode);
  }

  updateThemeStyle(String themeStyle) {
    updateTheme(themeStyle, currentThemeMode);
  }

  updateTheme(String themeStyle, ThemeMode themeMode) {
    currentThemeStyle = themeStyle;
    currentThemeMode = themeMode;
    AppTheme.instance.changeThemeStyle(currentThemeStyle, currentThemeMode);
    Get.forceAppUpdate();
  }
}
