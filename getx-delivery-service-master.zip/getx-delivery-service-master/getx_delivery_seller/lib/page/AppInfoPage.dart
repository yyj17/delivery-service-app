import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../controller/app_info_controller.dart';
import '../res/label.dart';
import '../res/theme/app_theme.dart';

class AppInfoPage extends GetView {
  const AppInfoPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GetBuilder<AppInfoController>(
      builder: (controller) {
        return Scaffold(
          body: Container(
            color: AppTheme.instance.currentTheme.backgroundColor,
            child: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    controller.appName,
                    style: Theme.of(context).textTheme.headline1?.copyWith(fontSize: 28),
                  ),
                  Text(
                    controller.appEnv,
                    style: Theme.of(context).textTheme.bodyText1,
                  ),
                  Obx(
                    () => Text(
                      controller.ip.value,
                      style: Theme.of(context).textTheme.bodyText1,
                    ),
                  ),
                  const Divider(),
                  Text(
                    LocaleKeys.genderWithArgMale.trArgs(["Tester"]),
                    style: Theme.of(context).textTheme.bodyText1?.copyWith(fontSize: 18),
                  ),
                  Text(
                    "my_wallet".tr,
                    style: Theme.of(context).textTheme.bodyText1?.copyWith(fontSize: 18),
                  ),
                  // Image.asset(
                  //   Assets.images.iconLoginUsername.path,
                  //   width: 100,
                  //   height: 100,
                  //   color: AppTheme
                  //       .instance.currentTheme.projectTheme.primaryLight,
                  // ),
                  DropdownButton<Locale>(
                    value: controller.currentLocale,
                    items: controller.localeList
                        .map((e) => DropdownMenuItem(
                              value: e.values.first,
                              child: Text(
                                e.keys.first,
                              ),
                            ))
                        .toList(),
                    onChanged: (value) => controller.updateLanguge(locale: value),
                  ),
                  DropdownButton<String>(
                    value: controller.currentThemeStyle,
                    items: AppTheme.instance.themeModeData.keys
                        .toList()
                        .map((e) => DropdownMenuItem(
                              value: e,
                              child: Text(
                                e,
                              ),
                            ))
                        .toList(),
                    onChanged: (value) => controller.updateThemeStyle(value!),
                  ),
                  DropdownButton<ThemeMode>(
                    value: controller.currentThemeMode,
                    items: controller.themeModeList
                        .map((e) => DropdownMenuItem(
                              value: e,
                              child: Text(
                                e.name,
                              ),
                            ))
                        .toList(),
                    onChanged: (value) => controller.updateThemeMode(value!),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}
