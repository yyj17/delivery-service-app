import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../routes/app_page.dart';

class MenuPage extends StatelessWidget {
  const MenuPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(),
      body: Builder(builder: (context) {
        return Column(
          children: [
            Expanded(
              child: ListView.builder(
                shrinkWrap: true,
                scrollDirection: Axis.vertical,
                itemCount: AppPage.menuRoutes.first.children.length,
                itemBuilder: (context, index) {
                  return Card(
                    child: ListTile(
                      title:
                          Text(AppPage.menuRoutes.first.children[index].name),
                      onTap: () {
                        Get.toNamed(
                            "${AppPage.menuRoutes.first.name}${AppPage.menuRoutes.first.children[index].name}");
                      },
                    ),
                  );
                },
              ),
            ),
          ],
        );
      }),
    );
  }
}
