import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../res/shared_preference_key.dart';
import '../routes/app_routes.dart';
import '../service/auth_service.dart';

class HomePage extends StatelessWidget {
  const HomePage({Key? key}) : super(key: key);

  SharedPreferences get _sharedPreferences => Get.find<SharedPreferences>();
  TextStyle get _textStyle => const TextStyle(fontSize: 25, fontWeight: FontWeight.bold, color: Colors.black);

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.purple,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            _sharedPreferences.getString(SharedPreferenceKey.uid) ?? "uid not found",
            style: _textStyle,
          ),
          Text(
            _sharedPreferences.getString(SharedPreferenceKey.email) ?? "email not found",
            style: _textStyle,
          ),
          Text(
            _sharedPreferences.getString(SharedPreferenceKey.name) ?? "name not found",
            style: _textStyle,
          ),
          Text(
            _sharedPreferences.getString(SharedPreferenceKey.photoUrl) ?? "photoUrl not found",
            style: _textStyle,
          ),
          ElevatedButton(
            style: ButtonStyle(
              shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(30.0),
                ),
              ),
              minimumSize: MaterialStateProperty.all(const Size(50, 50)),
              backgroundColor: MaterialStateProperty.all(Colors.transparent),
              shadowColor: MaterialStateProperty.all(Colors.transparent),
            ),
            child: Padding(
              padding: const EdgeInsets.fromLTRB(40, 10, 40, 10),
              child: Text(
                'Sign In'.toUpperCase(),
                style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.white),
              ),
            ),
            onPressed: () {
              Get.find<AuthService>().signOut();
              Get.offNamed(AppRoutes.loginPage);
            },
          )
        ],
      ),
    );
  }
}
