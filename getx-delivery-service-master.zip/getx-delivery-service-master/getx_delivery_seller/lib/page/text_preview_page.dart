import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';

import '../controller/app_info_controller.dart';
import '../widgets/textfield/arrow_down_icon.dart';
import '../widgets/textfield/drop_down_text_field.dart';
import '../widgets/textfield/obscure_text_field.dart';

class TextPreviewPage extends GetView<AppInfoController> {
  final TextEditingController _themeController = TextEditingController()..text = "light theme";
  final themeSelectionList = [
    SelectOption(
      id: 0,
      name: "light theme",
    ),
    SelectOption(
      id: 1,
      name: "dark theme",
    ),
    SelectOption(
      id: 2,
      name: "blue light theme",
    ),
    SelectOption(
      id: 3,
      name: "blue dark theme",
    ),
  ];

  TextPreviewPage({Key? key}) : super(key: key);

  _themeSelectHandler(SelectOption selectOption) {
    String themeStyle;
    ThemeMode themeMode;
    if (selectOption.id == 0) {
      themeStyle = "default";
      themeMode = ThemeMode.light;
    } else if (selectOption.id == 1) {
      themeStyle = "default";
      themeMode = ThemeMode.dark;
    } else if (selectOption.id == 2) {
      themeStyle = "blue";
      themeMode = ThemeMode.light;
    } else {
      themeStyle = "blue";
      themeMode = ThemeMode.dark;
    }
    controller.updateTheme(themeStyle, themeMode);
  }

  @override
  Widget build(BuildContext context) {
    final defaultInputDecoration = const InputDecoration().applyDefaults(Theme.of(context).inputDecorationTheme);

    return GetBuilder<AppInfoController>(
      builder: (controller) {
        return Scaffold(
          appBar: AppBar(),
          body: Container(
            color: Theme.of(context).backgroundColor,
            child: ListView(
              padding: const EdgeInsets.all(8.0),
              children: [
                DropDownTextField(
                  builder: ({controller, onTap}) {
                    return TextFormField(
                      controller: controller,
                      onTap: onTap,
                      decoration: defaultInputDecoration.copyWith(
                        suffixIcon: const ArrowDownIcon(),
                      ),
                      enableInteractiveSelection: false,
                      readOnly: true,
                    );
                  },
                  controller: _themeController,
                  bottomSheetTitle: "Theme",
                  selectedOption: themeSelectionList.first,
                  selectionList: themeSelectionList,
                  onSelection: _themeSelectHandler,
                ),
                const SizedBox(height: 10),
                TextFormField(
                  decoration: defaultInputDecoration.copyWith(hintText: "default text field"),
                  keyboardType: TextInputType.emailAddress,
                  textInputAction: TextInputAction.next,
                  obscureText: false,
                  inputFormatters: [
                    FilteringTextInputFormatter.allow(RegExp("[0-9a-zA-Z]")),
                  ],
                ),
                const SizedBox(height: 10),
                TextFormField(
                  decoration: defaultInputDecoration.copyWith(
                    prefixIcon: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 12.0),
                      child: Builder(builder: (context) {
                        return Image.asset(
                          "assets/images/icon-login-username.png",
                          width: 20.0,
                          fit: BoxFit.fitWidth,
                          color: Theme.of(context).inputDecorationTheme.prefixIconColor,
                        );
                      }),
                    ),
                    hintText: "email text field",
                  ),
                  keyboardType: TextInputType.emailAddress,
                  textInputAction: TextInputAction.next,
                  obscureText: false,
                  inputFormatters: [
                    FilteringTextInputFormatter.allow(RegExp("[0-9a-zA-Z]")),
                  ],
                ),
                const SizedBox(height: 10),
                ObscureTextField(builder: ({isObscure, suffixIcon}) {
                  return TextFormField(
                    decoration: defaultInputDecoration.copyWith(
                      hintText: "theme password text field",
                      prefixIcon: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 12.0),
                        child: Builder(builder: (context) {
                          return Image.asset(
                            "assets/images/icon-login-password.png",
                            width: 20.0,
                            fit: BoxFit.fitWidth,
                            color: Theme.of(context).inputDecorationTheme.prefixIconColor,
                          );
                        }),
                      ),
                      suffixIcon: suffixIcon,
                    ),
                    keyboardType: TextInputType.visiblePassword,
                    textInputAction: TextInputAction.next,
                    obscureText: isObscure ?? false,
                    inputFormatters: [
                      FilteringTextInputFormatter.allow(RegExp("[0-9a-zA-Z]")),
                    ],
                  );
                })
              ],
            ),
          ),
        );
      },
    );
  }
}
