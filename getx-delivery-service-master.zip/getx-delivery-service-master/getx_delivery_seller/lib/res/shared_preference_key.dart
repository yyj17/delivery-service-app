class SharedPreferenceKey {
  static const uid = "uid";
  static const email = "email";
  static const name = "name";
  static const photoUrl = "photoUrl";
}
