import 'package:flutter/material.dart';

/// [ThemeData.subtitle1] default color for input text
///
/// [ThemeData.textSelectionTheme.cursorColor] default cursor color
///
/// [ThemeData.canvasColor] default dropdown color
class AppTheme {
  late ThemeData _currentTheme;
  ThemeMode _currentThemeMode = ThemeMode.light;
  late String _currentThemeStyle;

  late ThemeData _light;
  late ThemeData _dark;
  late ThemeData _blue;
  Map<String, Map<ThemeMode, ThemeData>> themeModeData = {};

  final _pageTransitionsTheme = const PageTransitionsTheme(
    builders: {
      TargetPlatform.android: ZoomPageTransitionsBuilder(),
      TargetPlatform.iOS: CupertinoPageTransitionsBuilder(),
    },
  );

  String get currentThemeStyle => _currentThemeStyle;
  ThemeMode get currentThemeMode => _currentThemeMode;
  ThemeData get currentTheme => _currentTheme;

  static final instance = AppTheme._();

  AppTheme._() {
    _light = ThemeData(
      primaryColor: Colors.orange,
      backgroundColor: Colors.white,
      hintColor: Colors.grey,
      canvasColor: Colors.white,
      errorColor: Colors.red,

      textTheme: _getTextTheme(
        headColor: Colors.black,
        bodyColor: Colors.black,
        titleColor: Colors.black,
        subtitleColor: Colors.black,
      ),
      textSelectionTheme: const TextSelectionThemeData(cursorColor: Colors.grey),
      // error color show on the border
      colorScheme: ColorScheme.fromSeed(
        seedColor: Colors.white,
        brightness: Brightness.light,
      ),
      inputDecorationTheme: _getInputDecorationTheme(
        labelColor: Colors.black,
        fillColor: Colors.white,
        hintColor: Colors.grey,
        errorColor: Colors.red,
        borderColor: Colors.black,
        errorBorderColor: Colors.red,
        prefixColor: Colors.grey,
        suffixColor: Colors.grey,
      ),
      elevatedButtonTheme: _getCustomElevatedButtonTheme(),
      outlinedButtonTheme: _getCustomOutlinedButtonTheme(),
      textButtonTheme: _getCustomTextButtonTheme(),
    );

    _dark = ThemeData(
      primaryColor: Colors.white,
      backgroundColor: Colors.black,
      hintColor: Colors.grey,
      canvasColor: Colors.black,
      errorColor: Colors.yellow,
      textTheme: _getTextTheme(
        headColor: Colors.white,
        bodyColor: Colors.white,
        titleColor: Colors.white,
        subtitleColor: Colors.white,
      ),
      textSelectionTheme: const TextSelectionThemeData(cursorColor: Colors.lightBlueAccent),
      colorScheme: ColorScheme.fromSeed(
        seedColor: Colors.black,
        brightness: Brightness.dark,
      ),
      inputDecorationTheme: _getInputDecorationTheme(
        labelColor: Colors.white,
        fillColor: Colors.black,
        hintColor: Colors.grey,
        errorColor: Colors.white,
        borderColor: Colors.white,
        errorBorderColor: Colors.red,
        prefixColor: Colors.white,
        suffixColor: Colors.white,
      ),
      elevatedButtonTheme: _getCustomElevatedButtonTheme(),
      outlinedButtonTheme: _getCustomOutlinedButtonTheme(),
      textButtonTheme: _getCustomTextButtonTheme(),
      pageTransitionsTheme: _pageTransitionsTheme,
    );

    _blue = ThemeData(
      primaryColor: Colors.blue,
      backgroundColor: Colors.lightBlue,
      hintColor: Colors.amber,
      canvasColor: Colors.blue,
      errorColor: Colors.deepPurple,
      textTheme: _getTextTheme(
        headColor: Colors.blue[900],
        bodyColor: Colors.blue[900],
        titleColor: Colors.blue[900],
        subtitleColor: Colors.blue[900],
      ),
      textSelectionTheme: const TextSelectionThemeData(cursorColor: Colors.lightBlueAccent),
      colorScheme: ColorScheme.fromSeed(
        seedColor: Colors.blue,
        brightness: Brightness.light,
      ),
      inputDecorationTheme: _getInputDecorationTheme(
        labelColor: Colors.black,
        fillColor: Colors.lightBlue,
        hintColor: Colors.amber,
        errorColor: Colors.amber,
        borderColor: Colors.blue,
        errorBorderColor: Colors.amber,
        prefixColor: Colors.amber,
        suffixColor: Colors.amber,
        defaultBorder: const UnderlineInputBorder(
          borderSide: BorderSide(
            color: Colors.amber,
            width: 1,
          ),
        ),
      ),
      elevatedButtonTheme: _getCustomElevatedButtonTheme(),
      outlinedButtonTheme: _getCustomOutlinedButtonTheme(),
      textButtonTheme: _getCustomTextButtonTheme(),
    );

    _currentTheme = _light;

    themeModeData = {
      "default": {
        ThemeMode.light: _light,
        ThemeMode.dark: _dark,
      },
      "blue": {
        ThemeMode.light: _blue,
        ThemeMode.dark: _dark,
      }
    };
    _currentThemeStyle = "default";
  }

  changeThemeStyle(String themeStyle, ThemeMode themeMode) {
    var _themeData = themeModeData[themeStyle]?[themeMode];
    if (_themeData != null) _currentTheme = _themeData;
    _currentThemeStyle = themeStyle;
    _currentThemeMode = themeMode;
  }

  /// 2018 set
  /// headline1, headline2, headline3, headline4, headline5, headline6
  /// subtitle1, subtitle2
  /// bodyText1, bodyText2
  /// caption, button, overline
  ///
  /// 2021 set
  /// displayLarge, displayMedium, displaySmall
  /// headlineMedium, headlineSmall
  /// titleLarge, titleMedium, titleSmall
  /// bodyLarge, bodyMedium, bodySmall
  /// labelLarge, labelSmall
  TextTheme _getTextTheme({
    Color? headColor,
    Color? bodyColor,
    Color? titleColor,
    Color? subtitleColor,
    Color? captionColor,
    Color? buttonColor,
    Color? overlineColor,
  }) {
    return TextTheme(
      headline1: TextStyle(
        fontSize: 14,
        color: headColor,
        fontWeight: FontWeight.w400,
      ),
      headline2: TextStyle(
        fontSize: 14,
        color: headColor,
        fontWeight: FontWeight.w400,
      ),
      headline3: TextStyle(
        fontSize: 14,
        color: headColor,
        fontWeight: FontWeight.w400,
      ),
      headline4: TextStyle(
        fontSize: 14,
        color: headColor,
        fontWeight: FontWeight.w400,
      ),
      headline5: TextStyle(
        fontSize: 14,
        color: headColor,
        fontWeight: FontWeight.bold,
      ),
      headline6: TextStyle(
        fontSize: 14,
        color: headColor,
        fontWeight: FontWeight.bold,
      ),
      bodyText1: TextStyle(
        fontSize: 12,
        color: bodyColor,
      ),
      bodyText2: TextStyle(
        fontSize: 12,
        color: bodyColor,
      ),
      // default color for input text
      subtitle1: TextStyle(
        color: subtitleColor,
      ),
      subtitle2: TextStyle(
        color: subtitleColor,
      ),
      caption: TextStyle(
        color: captionColor,
      ),
      button: TextStyle(
        color: buttonColor,
      ),
      overline: TextStyle(
        color: overlineColor,
      ),
    );
  }

  InputDecorationTheme _getInputDecorationTheme({
    Color? labelColor,
    Color? fillColor,
    Color? hintColor,
    Color? errorColor,
    Color borderColor = Colors.white,
    Color errorBorderColor = Colors.red,
    Color? prefixColor,
    Color? suffixColor,
    InputBorder? defaultBorder,
  }) {
    return InputDecorationTheme(
      labelStyle: TextStyle(
        fontSize: 14,
        color: labelColor,
        fontWeight: FontWeight.w400,
      ),
      filled: true,
      fillColor: fillColor,
      hintStyle: TextStyle(color: hintColor),
      errorStyle: TextStyle(color: errorColor),
      border: OutlineInputBorder(
        borderSide: BorderSide(
          color: borderColor,
          width: 1,
        ),
        borderRadius: const BorderRadius.all(Radius.circular(30)),
      ),
      enabledBorder: defaultBorder ??
          OutlineInputBorder(
            borderSide: BorderSide(
              color: borderColor,
              width: 1,
            ),
            borderRadius: const BorderRadius.all(Radius.circular(30)),
          ),
      focusedBorder: defaultBorder ??
          OutlineInputBorder(
            borderSide: BorderSide(
              color: borderColor,
              width: 1,
            ),
            borderRadius: const BorderRadius.all(Radius.circular(30)),
          ),
      errorBorder: defaultBorder ??
          OutlineInputBorder(
            borderSide: BorderSide(
              color: errorBorderColor,
              width: 1,
            ),
            borderRadius: const BorderRadius.all(Radius.circular(30)),
          ),
      prefixIconColor: prefixColor,
      suffixIconColor: suffixColor,
      prefixStyle: TextStyle(color: prefixColor),
      suffixStyle: TextStyle(color: suffixColor),
    );
  }

  TextStyle _getElevatedButtonTextStyleDark() {
    return const TextStyle(
      fontSize: 14,
      color: Colors.black,
    );
  }

  ElevatedButtonThemeData _getCustomElevatedButtonTheme() {
    return ElevatedButtonThemeData(
      style: ElevatedButton.styleFrom(
        primary: const Color(0xFF57FFAD),
        //onPrimary: Colors.green,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16.0),
        ),
        textStyle: _getElevatedButtonTextStyleDark(),
        shadowColor: Colors.transparent,
        elevation: 0,
      ),
    );
  }

  OutlinedButtonThemeData _getCustomOutlinedButtonTheme() {
    return OutlinedButtonThemeData(
      style: OutlinedButton.styleFrom(
        side: const BorderSide(
          color: Colors.transparent,
        ),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16.0),
        ),
        elevation: 0,
        textStyle: const TextStyle(fontSize: 16),
      ),
    );
  }

  TextButtonThemeData _getCustomTextButtonTheme() {
    return TextButtonThemeData(
      style: TextButton.styleFrom(
        textStyle: const TextStyle(
          fontWeight: FontWeight.w400,
          fontSize: 13.0,
          decoration: TextDecoration.underline,
        ),
      ),
    );
  }
}
