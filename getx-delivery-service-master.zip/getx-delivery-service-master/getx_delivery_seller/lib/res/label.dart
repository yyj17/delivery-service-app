class LocaleKeys {
  static const String noData = 'no_data';
  static const String touchScreenToTryAgain = 'touch_screen_to_try_again';
  static const String connectionError = 'connection_error';
  static const String parseError = 'parse_error';
  static const String genderWithArgMale = 'gender_with_arg_male';
}
