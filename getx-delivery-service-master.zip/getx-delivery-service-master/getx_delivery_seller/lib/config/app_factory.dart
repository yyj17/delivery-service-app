import 'package:flutter/material.dart';
import 'package:logger/logger.dart';

import '../server/server_repository.dart';
import '../utils/loading_utils.dart';

enum Env {
  dev,
  prod,
}

abstract class IServerRepository {
  late String apiEndPoint, appXAuth;
  late String langId;

  LoadingUtils get loadingUtils;

  log(dynamic message, {String? title, dynamic error, StackTrace? stackTrace});
}

class AppFactory implements IServerRepository {
  @override
  late String apiEndPoint, appXAuth;
  @override
  String langId = "en";
  late ServerRepository serverRepository;
  late LoadingUtils _loadingUtils;
  late Env _env;
  late Locale appLocale;

  final bool inProduction = const bool.fromEnvironment("dart.vm.product");
  final String appName = const String.fromEnvironment("DEFINE_APP_DISPLAY_NAME", defaultValue: "Delivery Service User");
  final String appEnv = const String.fromEnvironment("DEFINE_ENV", defaultValue: "prod");

  final _logger = Logger(
    output: ConsoleOutput(),
    printer: HybridPrinter(
      PrettyPrinter(),
      debug: PrettyPrinter(printTime: true),
    ),
  );

  Env get env => _env;

  bool get isDev => env == Env.dev;

  @override
  LoadingUtils get loadingUtils => _loadingUtils;

  AppFactory() {
    _env = Env.values.firstWhere((element) => element.toString() == "Env.$appEnv", orElse: () => Env.prod);

    // setup server environment
    switch (env) {
      case Env.dev:
        apiEndPoint = "http://gtaapi.securelayers.cloud/api/app/v1/";
        appXAuth = "6Nghd2dFE92dwf2Fwf2DEq3EDR6ZJM8MfSRV1h0qYhfyIvnSdh2Dsis482dFkP1";
        break;
      case Env.prod:
        apiEndPoint = "http://gtaapi.securelayers.cloud/api/app/v1/";
        appXAuth = "6Nghd2dFE92dwf2Fwf2DEq3EDR6ZJM8MfSRV1h0qYhfyIvnSdh2Dsis482dFkP1";
        break;
    }
    serverRepository = ServerRepository(appFactory: this);
    serverRepository.baseUrl = apiEndPoint;

    // setup loading widget
    var loadingWidget = Container(
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border.all(
          color: Colors.white,
        ),
        borderRadius: const BorderRadius.all(Radius.circular(10)),
      ),
      width: 100,
      height: 100,
    );
    _loadingUtils = LoadingUtils(loadingWidget: loadingWidget);
  }

  @override
  log(dynamic message, {String? title, dynamic error, StackTrace? stackTrace}) {
    StringBuffer requestLog = StringBuffer();
    if (title != null) {
      requestLog.writeln('===================== $title =====================');
    }
    if (message is Map) {
      message.forEach((key, value) {
        requestLog.writeln('$key = $value');
      });
    } else {
      requestLog.writeln(message);
    }
    if (error == null) {
      _logger.d(requestLog);
    } else {
      _logger.wtf(requestLog, error, stackTrace);
    }
  }
}
