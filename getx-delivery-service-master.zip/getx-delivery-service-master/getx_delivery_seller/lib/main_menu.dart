import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'binding/initial_binding.dart';
import 'res/theme/app_theme.dart';
import 'routes/app_page.dart';
import 'routes/app_routes.dart';
import 'service/app_service.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await AppService().initService();
  runApp(const MainApp());
}

class MainApp extends StatefulWidget {
  const MainApp({Key? key}) : super(key: key);

  @override
  State<MainApp> createState() => _MainAppState();
}

class _MainAppState extends State<MainApp> {
  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      locale: Get.deviceLocale ?? const Locale("en"),
      theme: AppTheme.instance.currentTheme,
      initialBinding: InitialBinding(),
      initialRoute: AppRoutes.menuPage,
      getPages: AppPage.menuRoutes,
    );
  }
}
