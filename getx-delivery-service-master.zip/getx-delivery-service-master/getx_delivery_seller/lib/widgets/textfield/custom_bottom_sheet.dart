import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import 'drop_down_text_field.dart';

class CustomBottomSheet extends StatelessWidget {
  final String? title;
  final String _title = "Title";
  final String? topLeftText;
  final String _topLeftText = "Cancel";
  final String? topRightText;
  final String _topRightText = "Done";
  final List<SelectOption>? list;
  final Function(SelectOption)? onSelect;

  const CustomBottomSheet({
    Key? key,
    this.title,
    this.list,
    this.onSelect,
    this.topLeftText,
    this.topRightText,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    SelectOption? selectOption;
    int initialItem =
        list?.indexWhere((element) => element.id == selectOption?.id) ?? 0;

    return Container(
      color: Colors.white,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Stack(
            alignment: Alignment.center,
            children: [
              Text(
                title ?? _title,
                style: Theme.of(context)
                    .textTheme
                    .headline2
                    ?.copyWith(fontSize: 18.0),
              ),
              Align(
                alignment: Alignment.centerLeft,
                child: TextButton(
                  child: Text(
                    topLeftText ?? _topLeftText,
                    style: Theme.of(context)
                        .textTheme
                        .headline1
                        ?.copyWith(color: Theme.of(context).primaryColorDark),
                  ),
                  onPressed: () => Navigator.of(context).pop(),
                ),
              ),
              Align(
                alignment: Alignment.centerRight,
                child: TextButton(
                  child: Text(
                    topRightText ?? _topRightText,
                    style: Theme.of(context)
                        .textTheme
                        .headline1
                        ?.copyWith(color: Theme.of(context).primaryColorDark),
                  ),
                  onPressed: () {
                    Navigator.of(context).pop();
                    if (list?.isNotEmpty == true) {
                      onSelect?.call(selectOption ?? list!.first);
                    }
                  },
                ),
              ),
            ],
          ),
          Divider(color: Theme.of(context).primaryColorDark),
          SizedBox(
            height: 200.0,
            child: CupertinoPicker(
              itemExtent: 50,
              scrollController:
                  FixedExtentScrollController(initialItem: initialItem),
              onSelectedItemChanged: (index) =>
                  selectOption = list?.elementAt(index),
              children: List.generate(list?.length ?? 0, (index) {
                return Center(
                  child: Text(list?[index].name ?? ''),
                );
              }),
            ),
          ),
        ],
      ),
    );
  }
}
