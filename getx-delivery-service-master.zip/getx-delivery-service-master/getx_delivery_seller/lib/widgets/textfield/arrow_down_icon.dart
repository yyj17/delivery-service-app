import 'package:flutter/material.dart';

class ArrowDownIcon extends StatelessWidget {
  final Color? dropDownIconColor;

  const ArrowDownIcon({
    Key? key,
    this.dropDownIconColor,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(0, 12.0, 16.0, 12.0),
      child: Icon(
        Icons.keyboard_arrow_down,
        color: dropDownIconColor ??
            Theme.of(context).inputDecorationTheme.suffixIconColor,
      ),
    );
  }
}
