import 'package:flutter/material.dart';

import 'custom_bottom_sheet.dart';

typedef DropDownTextFieldBuilder = Widget Function(
    {TextEditingController? controller, void Function()? onTap});

class DropDownTextField extends StatelessWidget {
  final DropDownTextFieldBuilder builder;
  final TextEditingController? controller;
  final SelectOption? selectedOption;
  final List<SelectOption>? selectionList;
  final Function(SelectOption)? onSelection;
  final Function? onRefreshList;
  final String? bottomSheetTitle;
  final String? bottomSheetTopLeftText;
  final String? bottomSheetTopRightText;

  /// use to replace the default custom bottom sheet
  final Widget? bottomSheet;

  const DropDownTextField({
    Key? key,
    required this.builder,
    this.controller,
    this.selectedOption,
    this.selectionList,
    this.onSelection,
    this.onRefreshList,
    this.bottomSheet,
    this.bottomSheetTitle,
    this.bottomSheetTopLeftText,
    this.bottomSheetTopRightText,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return builder(
      controller: controller,
      onTap: () {
        if (selectionList?.isNotEmpty == true &&
            (selectionList?.length ?? 0) > 1) {
          showModalBottomSheet(
              context: context,
              builder: (context) {
                return bottomSheet ??
                    CustomBottomSheet(
                      title: bottomSheetTitle,
                      topLeftText: bottomSheetTopLeftText,
                      topRightText: bottomSheetTopRightText,
                      list: selectionList,
                      onSelect: (selectOption) {
                        onSelection?.call(selectOption);
                        controller?.text = selectOption.name ?? "";
                      },
                    );
              });
        } else {
          onRefreshList?.call();
        }
      },
    );
  }
}

class SelectOption {
  final int? id;
  final String? name;
  final String? code;

  SelectOption({
    this.id,
    this.name,
    this.code,
  });
}
