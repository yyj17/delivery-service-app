import 'package:flutter/material.dart';

typedef ObscureTextFieldBuilder = Widget Function(
    {bool? isObscure, Widget? suffixIcon});

class ObscureTextField extends StatefulWidget {
  final bool isObscure;
  final Color? iconColor;
  final ObscureTextFieldBuilder builder;

  const ObscureTextField({
    Key? key,
    this.isObscure = true,
    this.iconColor,
    required this.builder,
  }) : super(key: key);

  @override
  State<ObscureTextField> createState() => _ObscureTextFieldState();
}

class _ObscureTextFieldState extends State<ObscureTextField> {
  late ValueNotifier<bool> isObscure;

  @override
  void initState() {
    super.initState();
    isObscure = ValueNotifier<bool>(widget.isObscure);
  }

  @override
  void dispose() {
    isObscure.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return widget.builder(
      isObscure: isObscure.value,
      suffixIcon: _IconButton(
        color: widget.iconColor,
        isObscure: isObscure.value,
        onPressed: () => _onToggle(),
      ),
    );
  }

  _onToggle() {
    setState(() {
      isObscure.value = !isObscure.value;
    });
  }
}

class _IconButton extends StatelessWidget {
  final bool isObscure;
  final Color? color;
  final VoidCallback onPressed;

  const _IconButton(
      {Key? key, required this.isObscure, required this.onPressed, this.color})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return IconButton(
      icon: Icon(
        // Based on passwordVisible state choose the icon
        isObscure ? Icons.visibility_off : Icons.visibility,
        color: color ?? Theme.of(context).inputDecorationTheme.suffixIconColor,
      ),
      onPressed: onPressed,
    );
  }
}
