import 'package:flutter/material.dart';

class LoadingUtils {
  Future? _loadDialog;

  final Widget? loadingWidget;

  LoadingUtils({this.loadingWidget});

  showLoading(
    BuildContext context, {
    bool barrierDismissible = false,
  }) async {
    _loadDialog ??=
        _showLoadingDialog(context, barrierDismissible: barrierDismissible);
  }

  stopLoading(BuildContext context, {result}) {
    if (_loadDialog != null) {
      if (result != null) {
        Navigator.of(context).pop(result);
      } else {
        Navigator.of(context).pop();
      }
      _loadDialog = null;
    }
  }

  Future _showLoadingDialog(
    BuildContext context, {
    bool barrierDismissible = false,
  }) {
    return showDialog(
      context: context,
      barrierDismissible: barrierDismissible,
      builder: (context) {
        return WillPopScope(
          onWillPop: () {
            if (!barrierDismissible) {
              return Future.value(false);
            }
            _loadDialog = null;
            return Future.value(true);
          },
          child: Center(
            child: loadingWidget,
          ),
        );
      },
    );
  }
}
