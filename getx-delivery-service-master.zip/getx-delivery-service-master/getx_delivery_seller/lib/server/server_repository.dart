import 'package:get/get.dart';
import 'package:get/get_connect/http/src/request/request.dart';

import '../config/app_factory.dart';
import '../res/label.dart';
import 'response_entity.dart';

class ServerRepository extends GetConnect {
  IServerRepository appFactory;
  String? _accessToken;
  String _baseUrl = "";

  set accessToken(String? value) => _accessToken = value;

  ServerRepository({required this.appFactory}) {
    _initHttpService();
  }

  @override
  set baseUrl(String? _baseUrl) {
    this._baseUrl = _baseUrl ?? "";
  }

  _initHttpService() {
    httpClient.timeout = const Duration(seconds: 30);
    httpClient.addRequestModifier<void>((Request request) async {
      var requestLog = Map.from({
        'url': request.url,
        'headers': request.headers,
        'method': request.method,
      });
      appFactory.log(requestLog, title: 'Request');

      return request;
    });

    httpClient.addResponseModifier((request, response) {
      if (response.isOk) {
        var log = Map.from({
          'statusCode': response.statusCode,
          'url': request.url,
          'data': response.bodyString,
        });
        appFactory.log(log, title: "Response");
      }
      return response;
    });
  }

  /// [url] api endpoint
  ///
  /// [embedBaseUrl] set to false if not from [baseUrl]
  ///
  /// [embedData] set to true if the data inside the data model
  Future<ResponseEntity<T>> loadEntityData<T>(
    String url, {
    String method = 'POST',
    dynamic body,
    String? contentType,
    Map<String, String>? headers,
    Map<String, dynamic>? query,
    T Function(dynamic)? decoder,
    dynamic Function(double)? uploadProgress,
    bool? cacheJson,
    bool? embedData,
    bool showLoading = true,
    bool embedBaseUrl = true,
  }) async {
    try {
      if (embedBaseUrl) {
        url = _baseUrl + url;
      }
      if (showLoading && Get.overlayContext != null) {
        appFactory.loadingUtils.showLoading(Get.overlayContext!, barrierDismissible: true);
      }

      headers ??= {};
      headers['Content-Type'] = 'application/json';
      headers['X-Authorization'] = appFactory.appXAuth;
      headers['Accept-Language'] = appFactory.langId;
      if (_accessToken != null) {
        headers['authorization'] = _accessToken!;
      }

      if (body is FormData) {
        // body = body.baseParams;
        headers['Content-Type'] = 'multipart/form-data; boundary=${body.boundary}';
      } else if (body != null) {
        body = body as Map;
      }

      var response = await request<ResponseEntity<T>>(
        url,
        method,
        body: body,
        contentType: contentType,
        headers: headers,
        query: query,
        decoder: (data) {
          if (data is Map<String, dynamic>) {
            return ResponseEntity<T>.fromJson(
              data,
              fromJsonT: decoder,
              cacheJson: cacheJson,
              embedData: embedData,
            );
          } else if (data is List) {
            return ResponseEntity<T>.fromJsonList(
              data,
              fromJsonT: decoder,
              cacheJson: cacheJson,
            );
          } else {
            return ResponseEntity(
              success: false,
              message: LocaleKeys.parseError.tr,
            );
          }
        },
        uploadProgress: uploadProgress,
      );

      if (showLoading && Get.overlayContext != null) {
        appFactory.loadingUtils.stopLoading(Get.overlayContext!);
      }

      if (response.isOk) {
        return response.body!;
      } else if (response.statusCode == null) {
        return ResponseEntity(
          success: false,
          message: LocaleKeys.connectionError.tr,
        );
      } else {
        return ResponseEntity(
          success: false,
          message: response.statusText ?? '',
          statusCode: response.statusCode,
        );
      }
    } catch (e, s) {
      final runTimeLog = Map.from({
        'url': url,
        'headers': headers,
        'method': method,
        'body': body,
        'query': query,
        'info': decoder == null ? '### Please check the decoder whether is null ###' : '### Parse Error ###',
      });

      appFactory.log(runTimeLog, title: "Runtime Error", error: e, stackTrace: s);
      if (Get.overlayContext != null) {
        appFactory.loadingUtils.stopLoading(Get.overlayContext!);
      }

      return ResponseEntity(success: false, message: LocaleKeys.parseError.tr);
    }
  }
}
