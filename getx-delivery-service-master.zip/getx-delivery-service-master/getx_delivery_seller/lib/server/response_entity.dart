import 'package:get/get_connect/http/src/status/http_status.dart';

import 'response_entity_mixin.dart';

class ResponseEntity<T> with ResponseEntityMixin {
  late bool success;
  late String message;
  int? statusCode;
  Map<String, dynamic>? jsonMap;
  List? jsonList;

  T? data;
  List<T> listData = [];
  List list = [];

  ResponseEntity({
    required this.success,
    required this.message,
    this.statusCode,
    this.jsonMap,
  });

  ResponseEntity.fromJson(
    Map<String, dynamic> json, {
    T Function(Object json)? fromJsonT,
    bool? cacheJson,
    bool? embedData,
  }) {
    message = json["msg"] ?? '';

    if (cacheJson == true) {
      jsonMap = json;
    }

    success = checkEntity(json);
    if (!success) statusCode = HttpStatus.badRequest;

    List listObject(List list) {
      List newList = [];
      for (int i = 0; i < list.length; i++) {
        var item = list[i];
        if (item is List) {
          newList.add(listObject(item));
        } else if (item is String || item is int || item is double) {
          newList = list;
          break;
        } else {
          newList.add(fromJsonT?.call(item));
        }
      }
      return newList;
    }

    var _data = embedData == true ? json["data"]["data"] : json["data"];
    if (_data == null) {
      if (fromJsonT != null) {
        data = fromJsonT(json);
      } else {
        data = json as T;
      }
      success = true;
    } else {
      if (_data is List) {
        for (var item in _data) {
          if (item is List) {
            List tempList = listObject(item);
            list.add(tempList);
          } else {
            if (fromJsonT != null) {
              listData.add(fromJsonT(item));
            } else {
              listData.add(item);
            }
          }
        }
      } else {
        if (fromJsonT != null) {
          data = fromJsonT(_data);
        } else {
          data = _data;
        }
      }
    }
  }

  ResponseEntity.fromJsonList(
    List json, {
    T Function(Object json)? fromJsonT,
    bool? cacheJson,
  }) {
    if (cacheJson == true) {
      jsonList = json;
    }
    try {
      if (fromJsonT == null) {
        data = json.map((e) => Map.from(e)).toList() as T;
      } else {
        data = fromJsonT(json);
      }
      success = true;
    } catch (e) {
      success = false;
    }
  }
}
