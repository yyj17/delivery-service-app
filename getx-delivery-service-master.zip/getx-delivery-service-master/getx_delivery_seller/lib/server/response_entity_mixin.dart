mixin ResponseEntityMixin {
  bool checkEntity(Map json) {
    if (json["rst"] != null) {
      String rst = '';
      if (json["rst"] is String) {
        rst = json["rst"];
      } else {
        rst = json["rst"].toString();
      }
      if (rst == '1') {
        return true;
      } else {
        return false;
      }
    }
    return false;
  }
}
