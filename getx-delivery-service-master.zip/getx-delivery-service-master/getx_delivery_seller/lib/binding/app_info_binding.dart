import 'package:get/get.dart';

import '../controller/app_info_controller.dart';

class AppInfoBinding implements Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => AppInfoController(), fenix: true);
  }
}
