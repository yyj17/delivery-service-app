import 'package:get/get.dart';

import '../controller/splash_screen_page_controller.dart';

class SplashScreenPageBinding implements Bindings {
  @override
  void dependencies() {
    Get.put(SplashScreenPageController());
  }
}
