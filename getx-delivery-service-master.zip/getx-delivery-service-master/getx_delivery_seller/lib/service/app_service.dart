import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:getx_delivery_seller/service/auth_service.dart';
import 'package:getx_delivery_seller/service/seller_service.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../config/app_factory.dart';
import '../res/theme/app_theme.dart';

class AppService {
  initService() async {
    await Get.putAsync(() => SharedPreferences.getInstance());

    AppTheme.instance.changeThemeStyle(AppTheme.instance.currentThemeStyle, ThemeMode.light);
    Get.lazyPut(() => AppFactory(), fenix: true);
    await _setupService();
    await _setupLocalization();
  }

  _setupService() async {
    Get.lazyPut(() => AuthService(), fenix: true);
    Get.lazyPut(() => SellerService(), fenix: true);
  }

  _setupLocalization() async {
    // TODO: Handle translation
    // try {
    //   var jsonString =
    //       await rootBundle.loadString(Assets.locale.localizationJson);
    //   var translationData = Map.from(json.decode(jsonString)).map(
    //       (key, value) => MapEntry("$key",
    //           Map.from(value).map((key, value) => MapEntry("$key", "$value"))));
    //   Get.addTranslations(translationData);
    // } catch (e) {}
  }
}
