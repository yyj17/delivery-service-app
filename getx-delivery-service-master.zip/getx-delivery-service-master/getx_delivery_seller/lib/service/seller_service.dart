import 'package:cloud_firestore/cloud_firestore.dart';

import '../model/seller_model.dart';

class SellerService {
  Future<SellerModel?> getSellerData(String uid) async {
    SellerModel? data;
    await FirebaseFirestore.instance.collection("sellers").doc(uid).get().then((snapshot) {
      if (snapshot.exists && snapshot.data() != null) {
        final json = snapshot.data()!;

        final status = json['status'] != null ? json['status'].toString() : '';
        final email = json['sellerEmail'] != null ? json['sellerEmail'].toString() : '';
        final name = json['sellerName'] != null ? json['sellerName'].toString() : '';
        final avatarUrl = json['sellerAvatarUrl'] != null ? json['sellerAvatarUrl'].toString() : '';
        data = SellerModel(status: status, email: email, name: name, avatarUrl: avatarUrl);
      }
    });

    return data;
  }
}
