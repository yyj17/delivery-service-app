import '../model/ip_info_model.dart';
import '../server/response_entity.dart';
import 'base_service.dart';

class GeneralService extends BaseService {
  Future<ResponseEntity<IpInfoModel>> getIpInfo() async {
    var entity = await serverRepository.loadEntityData(
      "https://ipinfo.io/json",
      method: "GET",
      embedBaseUrl: false,
      showLoading: false,
      decoder: (json) {
        return IpInfoModel.fromJson(json);
      },
    );
    return entity;
  }

  Future<ResponseEntity> getIpInfoMap() async {
    var entity = await serverRepository.loadEntityData(
      "https://ipinfo.io/json",
      method: "GET",
      embedBaseUrl: false,
    );
    return entity;
  }

  Future<ResponseEntity> getTranslation(String languageCode) async {
    var entity = await serverRepository.loadEntityData(
      "locales/$languageCode",
      method: "GET",
      cacheJson: true,
    );
    return entity;
  }
}
