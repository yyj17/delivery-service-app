import 'package:get/get.dart';

import '../config/app_factory.dart';
import '../server/server_repository.dart';

class BaseService {
  ServerRepository get serverRepository {
    AppFactory appFactory = Get.find<AppFactory>();
    return appFactory.serverRepository;
  }
}
