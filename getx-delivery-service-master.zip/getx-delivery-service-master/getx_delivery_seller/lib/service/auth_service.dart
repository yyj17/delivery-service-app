import 'package:firebase_auth/firebase_auth.dart';

class AuthService {
  FirebaseAuth get firebaseAuth => FirebaseAuth.instance;

  bool isAuthenticated() {
    return firebaseAuth.currentUser != null;
  }

  Future<User?> signInWithEmailAndPassword({required String email, required String password}) async {
    final userCredential = await firebaseAuth
        .signInWithEmailAndPassword(
          email: email,
          password: password,
        )
        .catchError(
          (error) => throw error,
        );

    return userCredential.user!;
  }

  signOut() {
    firebaseAuth.signOut();
  }
}
