#!/bin/bash
config_file="./build.config"
if [ -f "$config_file" ]
then
  echo "$config_file found."

  while IFS='=' read -r key value
  do
    key=$(echo $key | tr '.' '_')
    eval ${key}=\${value}
  done < "$config_file"

  echo "app_name_dev       = " ${DEV_NAME}
  echo "app_id_dev         = " ${DEV_ID}
  echo "app_name_prod      = " ${PROD_NAME}
  echo "app_id_prod        = " ${PROD_ID}
else
  echo "$config_file not found."
fi

filename=ios/Flutter/Generated.xcconfig
build_target_directory="lib/main.dart"
echo "replace build target: "${build_target_directory//\//\\/}

read -p "Enter the build flavor (dev, prod, default prod): " build_flavor
if [ -z "$build_flavor" ]; then
  build_flavor="prod"
fi

if [[ $build_flavor == "dev" ]]; then
  app_name=${DEV_NAME}
  app_id=${DEV_ID}
elif [[ $build_flavor == "prod" ]]; then
  app_name=${PROD_NAME}
  app_id=${PROD_ID}
fi

echo $build_flavor
echo "app name: "${app_name}
echo "app id: "${app_id}

read -p "Enter the build name (default: 1.0.0): " build_name
if [[ $build_name == "" ]]; then
  build_name="1.0.0"
fi
echo  "build name: "$build_name

read -p "Enter the build number (default: 1): " build_number
if [[ $build_number == "" ]]; then
  build_number="1"
fi
echo "build number: "$build_number

build_device=0
read -p "Enter the build device (1: iOS, 2: Android, default: all): " build_device

if [[ $build_device -eq 0 || $build_device -eq 1 ]]; then
  if [[ $build_flavor == "dev" || $build_flavor == "stg" ]]; then
    export_option="ExportOptions-dev.plist"
  elif [[ $build_flavor == "prod" ]]; then
    export_option="ExportOptions-prod.plist"
  fi

  team_id=$(/usr/libexec/PlistBuddy -c "Print :teamID" ios/scripts/$export_option)
  if [ -z "$team_id" ]
  then
    exit 1
  fi

  echo "team id: "$team_id

  if [[ $build_flavor == "dev" ]]; then
    flutter build ios -t $build_target_directory --no-sound-null-safety --dart-define=DEFINE_APP_DISPLAY_NAME=${app_name} --dart-define=DEFINE_APP_ID=$app_id --dart-define=DEFINE_ENV=$build_flavor --dart-define=DEFINE_DEVELOPMENT_TEAM=$team_id
  elif [[ $build_flavor == "prod" ]]; then
    flutter build ios -t $build_target_directory --no-sound-null-safety --dart-define=DEFINE_APP_DISPLAY_NAME=${app_name} --dart-define=DEFINE_APP_ID=$app_id --dart-define=DEFINE_ENV=$build_flavor --dart-define=DEFINE_DEVELOPMENT_TEAM=$team_id
  fi
  sed -i "" -e "s|^FLUTTER_TARGET.*|FLUTTER_TARGET=${build_target_directory//\//\\/}|g" $filename
  sed -i "" -e "s|^FLUTTER_BUILD_NAME.*|FLUTTER_BUILD_NAME=$build_name|g" $filename
  sed -i "" -e "s|^FLUTTER_BUILD_NUMBER.*|FLUTTER_BUILD_NUMBER=$build_number|g" $filename

  xcodebuild -workspace ios/Runner.xcworkspace -scheme Runner archive -archivePath build/ios/Runner.xcarchive -destination generic/platform=iOS
  #Check if build succeeded
  if [ $? != 0 ]
  then
    exit 1
  fi
  xcodebuild -exportArchive -archivePath build/ios/Runner.xcarchive -exportOptionsPlist ios/scripts/$export_option -exportPath build/ios/iphone -allowProvisioningUpdates
  rm -fr build/ios/Runner.xcarchive
fi

if [[ $build_device -eq 0 || $build_device -eq 2 ]]; then
  if [[ $build_flavor == "dev" ]]; then
    flutter build apk -t $build_target_directory --no-sound-null-safety --build-name=$build_name --build-number=$build_number --dart-define=DEFINE_APP_DISPLAY_NAME=${app_name} --dart-define=DEFINE_APP_ID=$app_id --dart-define=DEFINE_ENV=$build_flavor
  elif [[ $build_flavor == "prod" ]]; then
    read -p "Enter the bundle type (apk, aab, default aab): " bundle_type
    if [[ $bundle_type == "" ]]; then
      bundle_type="aab"
    fi

    if [[ $bundle_type == "apk" ]]; then
      flutter build apk -t $build_target_directory --no-sound-null-safety --build-name=$build_name --build-number=$build_number --dart-define=DEFINE_APP_DISPLAY_NAME=${app_name} --dart-define=DEFINE_APP_ID=$app_id --dart-define=DEFINE_ENV=$build_flavor
      if [ $? != 0 ]
      then
        exit 1
      fi
      mv "build/app/outputs/flutter-apk/app-release.apk" "build/app/outputs/flutter-apk/${app_name}_${build_name}_${build_number}.apk"
    elif [[ $bundle_type == "aab" ]]; then
      flutter build appbundle -t $build_target_directory --no-sound-null-safety --build-name=$build_name --build-number=$build_number --dart-define=DEFINE_APP_DISPLAY_NAME=${app_name} --dart-define=DEFINE_APP_ID=$app_id --dart-define=DEFINE_ENV=$build_flavor
    fi
  fi
fi
