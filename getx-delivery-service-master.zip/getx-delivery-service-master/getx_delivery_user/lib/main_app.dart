import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'binding/initial_binding.dart';
import 'res/theme/app_theme.dart';
import 'routes/app_page.dart';
import 'routes/app_routes.dart';

class MainApp extends StatefulWidget {
  const MainApp({Key? key}) : super(key: key);

  @override
  State<MainApp> createState() => _MainAppState();
}

class _MainAppState extends State<MainApp> {
  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      locale: Get.deviceLocale ?? const Locale("en"),
      theme: AppTheme.instance.currentTheme,
      initialBinding: InitialBinding(),
      initialRoute: AppRoutes.appInfoPage,
      getPages: AppPage.routes,
    );
  }
}
