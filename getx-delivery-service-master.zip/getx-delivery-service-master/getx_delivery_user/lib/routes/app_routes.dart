class AppRoutes {
  static const String menuPage = "/menu";
  static const String appInfoPage = "/app_info_page";
}
