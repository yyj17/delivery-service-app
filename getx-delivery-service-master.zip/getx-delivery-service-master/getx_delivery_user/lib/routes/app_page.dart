import 'package:get/get.dart';
import 'package:getx_delivery_user/binding/app_info_binding.dart';
import 'package:getx_delivery_user/page/AppInfoPage.dart';

import '../page/menu_page.dart';
import 'app_routes.dart';

class AppPage {
  static final routes = [
    GetPage(
      name: AppRoutes.appInfoPage,
      page: () => const AppInfoPage(),
      binding: AppInfoBinding(),
    ),
  ];

  static final menuRoutes = [
    GetPage(
      name: AppRoutes.menuPage,
      page: () => const MenuPage(),
      children: routes,
    ),
  ];
}
