import 'state/state_controller.dart';

class SplashScreenPageController extends StateController {
  // bool get isAuthenticated => FirebaseAuth.instance.currentUser != null;
}
