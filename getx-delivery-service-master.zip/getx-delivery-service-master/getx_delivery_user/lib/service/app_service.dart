import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../config/app_factory.dart';
import '../res/theme/app_theme.dart';

class AppService {
  initService() async {
    AppTheme.instance.changeThemeStyle(AppTheme.instance.currentThemeStyle, ThemeMode.light);
    Get.lazyPut(() => AppFactory(), fenix: true);
    await _setupLocalization();
  }

  _setupLocalization() async {
    // TODO: Handle translation
    // try {
    //   var jsonString =
    //       await rootBundle.loadString(Assets.locale.localizationJson);
    //   var translationData = Map.from(json.decode(jsonString)).map(
    //       (key, value) => MapEntry("$key",
    //           Map.from(value).map((key, value) => MapEntry("$key", "$value"))));
    //   Get.addTranslations(translationData);
    // } catch (e) {}
  }
}
