package com.delivery.user

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
